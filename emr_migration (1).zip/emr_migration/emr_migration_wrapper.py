# Databricks notebook source
# MAGIC %md
# MAGIC ## Running Multiple Migrations 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Create Audit Table

# COMMAND ----------

from pyspark.sql.types import *

AUDIT_CATALOG = "sd_digivate_stage_catalog"
AUDIT_SCHEMA = "emr_migration"
AUDIT_LOG_TABLE = "emr_migration_log"

audit_schema = StructType([
    StructField("table_name", StringType(), False),
    StructField("s3_path", StringType(), False),
    StructField("start_time", TimestampType(), False),
    StructField("end_time", TimestampType(), True),
    StructField("status", StringType(), False),
    StructField("external_table", StringType(), False),
    StructField("managed_table", StringType(), False),
    StructField("rows_processed", IntegerType(), True),
    StructField("error_message", StringType(), True)
])

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {AUDIT_CATALOG}.{AUDIT_SCHEMA}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {AUDIT_CATALOG}.{AUDIT_SCHEMA}")
spark.sql(f"DROP TABLE IF EXISTS {AUDIT_CATALOG}.{AUDIT_SCHEMA}.{AUDIT_LOG_TABLE}")

empty_df = spark.createDataFrame([], audit_schema)
empty_df.write.format("delta").mode("overwrite").saveAsTable(f"{AUDIT_CATALOG}.{AUDIT_SCHEMA}.{AUDIT_LOG_TABLE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ###S3 Metadata Information

# COMMAND ----------

# Create a uc table with all id, txn or non_txn, s3 location, original schema, external schema, external table_names, final schema, final tablenames, sizes of the table


#external_table  = sd_digivate_stage_catalog.migration_approach
#final_table  = sd_digivate_stage_catalog.snapdeal_non_txn
#final_table  = sd_digivate_stage_catalog.snapdeal_txn
#original_schema = dp_preprod_digivate.nontxn
#original_schema = dp_preprod_digivate.txn

# COMMAND ----------

# MAGIC %md
# MAGIC ###Classify the tables according to sizes

# COMMAND ----------

#create audit log
#call small tables in 20 threads -- emr_migrate_main
#update audit log as error or success

# COMMAND ----------

#create audit log
#call medium tables in 10 threads -- emr_migrate_main
#update audit log as error or success

# COMMAND ----------

#create audit log
#call large tables in 4 threads -- emr_migrate_main
#update audit log as error or success

# COMMAND ----------

#create audit log
#call extra large tables in 2 threads -- emr_migrate_main
#update audit log as error or success