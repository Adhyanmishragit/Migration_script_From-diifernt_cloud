# Databricks notebook source
import boto3
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, LongType

def get_folder_sizes(bucket_name, prefix):
    access=dbutils.secrets.get(scope='sd-preprod-dataplatform', key='dataplatform_prd_digivate_s3_bucket_access_key')
    secret=dbutils.secrets.get(scope='sd-preprod-dataplatform', key='dataplatform_prd_digivate_s3_bucket_secret_key')
    
    s3 = boto3.client(
        's3',
        aws_access_key_id=access,
        aws_secret_access_key=secret
    )
    spark = SparkSession.builder.getOrCreate()
    schema = StructType([
        StructField("folder_name", StringType(), True),
        StructField("total_size", LongType(), True)
    ])
    
    result_data = []
    
    prefix = prefix.rstrip('/') + '/'
    
    paginator = s3.get_paginator('list_objects_v2')
    
    child_folders = set()
    folder_sizes = {}
    
    for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix, Delimiter='/'):
        if 'CommonPrefixes' in page:
            for common_prefix in page['CommonPrefixes']:
                child_prefix = common_prefix['Prefix']
                child_folder = child_prefix.replace(prefix, '').split('/')[0]
                child_folders.add(child_folder)
                folder_sizes[child_folder] = 0
    
    for child_folder in child_folders:
        child_prefix = prefix + child_folder + '/'
        
        for page in paginator.paginate(Bucket=bucket_name, Prefix=child_prefix):
            if 'Contents' in page:
                for obj in page['Contents']:
                    folder_sizes[child_folder] += obj['Size']
    
    for folder, size in folder_sizes.items():
        result_data.append((folder, size))
    
    return spark.createDataFrame(result_data, schema)

# COMMAND ----------

txn_folder = 's3://dataplatform-batchdata-prd/user/dataplatform/sourcedata/ep/transactional/sd/'
txn_result_df = get_folder_sizes('dataplatform-batchdata-prd', 'user/dataplatform/sourcedata/ep/transactional/sd/')
display(txn_result_df)
#sd_digivate_stage_catalog.migration_approach.txn_metadata

# COMMAND ----------


non_txn_folder = 's3://dataplatform-batchdata-prd/user/dataplatform/sourcedata/ep/behavioural/sd/'
result_df = get_folder_sizes('dataplatform-batchdata-prd', 'user/dataplatform/sourcedata/ep/behavioural/sd/')
display(result_df)
#sd_digivate_stage_catalog.migration_approach.non_txn_metadata