-- Databricks notebook source
CREATE OR REPLACE TABLE {destination_table}
PARTITIONED BY ({partition_columns})
AS SELECT * FROM {external_table}