# Databricks notebook source
# call create_external_table with the parameters

# COMMAND ----------

sd_digivate_stage_catalog.migration_approachfrom pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException

# original_schema is the final expected schema for this table
original_df = spark.read.table("dataplatform_preprod.nontxn.addtocart")
original_schema = original_df.schema

# source_schema is your external table
source_df = spark.read.table("sd_digivate_stage_catalog.migration_approach.addtocart")
source_schema = source_df.schema
# Convert source schema to target schema
if source_schema != original_schema:
    for field in original_schema:
        if field.name not in source_df.columns:
            source_df = source_df.withColumn(field.name, lit(None).cast(field.dataType))
        elif source_df.schema[field.name].dataType != field.dataType:
            spark.sql(f"ALTER TABLE sd_digivate_stage_catalog.migration_approach.addtocart CHANGE COLUMN {field.name} {field.name} {field.dataType.simpleString()}")

source_df = source_df.select([field.name for field in original_schema])



# COMMAND ----------

#call copy table notebook with params