-- Databricks notebook source
CREATE TABLE {external_table_name}
USING parquet
LOCATION '{s3_location}';